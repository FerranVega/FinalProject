library(testthat)
library(btergm)

test_check("btergm")
